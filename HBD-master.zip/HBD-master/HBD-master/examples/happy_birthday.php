/*
@author vinitshahdeo
*/
<?php  
$data = base64_decode('SGFwcHkgQmlydGhkYXkh');
echo $data; 
?>
