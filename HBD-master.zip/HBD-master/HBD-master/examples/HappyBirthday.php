<?php
$result = "Happy Birthday!";
var_dump($result);
?>