import time as t

def Happy():
	t.sleep(1)
	print('\n\n\t\t __ __    ____   ____   ____   __ __')
	t.sleep(1)
	print('\t\t|  |  |  /    | |     \|     \|  |  |')
	t.sleep(.8)
	print('\t\t|  |  | |  o  | |  o   )  o   )  |  |')
	t.sleep(.8)
	print('\t\t|  _  | |     | |    _/|    _/|  ~  |')
	t.sleep(.8)
	print('\t\t|     | |  _  | |   |  |   |  |___  |')
	t.sleep(.8)
	print('\t\t|  |  | |  |  | |   |  |   |  |  |  |')
	t.sleep(.8)
	print('\t\t|__|__| |__|__| |___|  |___|  |____/')
	
def Birthday():
	t.sleep(.9)
	print('\t\t\t ____   ____   ____  ______  __ __   ___     ____   __ __  ')
	t.sleep(.8)
	print('\t\t\t|    \ |    | |    \|_    _||  |  | |   \   /    | |  |  |  ')
	t.sleep(.7)
	print('\t\t\t| o   ) |  |  |  D  ) |  |  |  |  | |    \ |  o  | |  |  |  ')
	t.sleep(.7)
	print('\t\t\t|    |  |  |  |   _/  |  |  |  _  | |  D | |     | |  ~  |')
	t.sleep(.7)
	print('\t\t\t| o  |  |  |  |   \   |  |  |  |  | |    | |     | |___  |')
	t.sleep(.7)
	print('\t\t\t|    |  |  |  |  . \  |  |  |  |  | |    | |  |  | |     |')
	t.sleep(.7)
	print('\t\t\t|____| |____| |__|\_| |__|  |__|__| |____| |__|__| |____/')

def Bro():
	t.sleep(.8)
	print('\t ____   ____    _______  ')
	t.sleep(.8)
	print('\t|    \ |    \  |   _   |')
	t.sleep(.8)
	print('\t| o   )|  D  ) |  | |  | ')
	t.sleep(.7)
	print('\t|    | |   _/  |  | |  | ')
	t.sleep(.7)
	print('\t| o  | |   \   |  | |  | ')
	t.sleep(.7)
	print('\t|    | |  . \  |  |_|  | ')
	t.sleep(.7)
	print('\t|____| |__|\_| \_______/\n\n')
		
	

#©TAMOJEET_KUILA

Happy()
Birthday()
Bro()
